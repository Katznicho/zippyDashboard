<?php

namespace App\Filament\Resources\IndividualCustomerResource\Pages;

use App\Filament\Resources\IndividualCustomerResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateIndividualCustomer extends CreateRecord
{
    protected static string $resource = IndividualCustomerResource::class;
}
